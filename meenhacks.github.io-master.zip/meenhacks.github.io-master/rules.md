# Rules
These are the Rules for the All the hackathon Events and Related Things
--------
1. The Problem Statements will be Given 2 days Ago. A team of 4-5 members are compulsory. 
-----
2 . You Should Not Start with the Project Before the Event.
  - If Found , you will be Disqualified from the Event and will not be eligible for Pizes or Presenting.
----
3. The Organizers nor Volunteers will not be held Responsible for your Properties. 
----
4. If we find any one Damages a property/equipment of The College, they'll be charged the Price of the Property Damaged, this will be non-partial.
----
5. Everyone Attending The Hackathon Has to pay the Fees of Rs.400.This Price is for the Tshirt,Venue Charges, Food Expenses etc...
----
6. Since this is a 24 Hour hackathon. People are not Expected to Sleep but those who want to Sleep will be given a Bed for naps.
----
7. Everyone attending Should bring their laptops to Hack-on, no laptops or accessories will be provided by the Organizers.
----
8. Those Who want to Hack-on Hardware, they should bring their own Hardware Equipment. If these components bring about any damage to the venue, They Will be charged for the Damages.
----
9. If anyone Uses the Internet Connectivity to Download Films, Pornographic content. They will be disqualified and the consequences will be same as 2.1.
----
10. If anyone is found out be Harassing Others, especially Women Participants will also be Disqualified by 2.1.
----
11. Attendees should Bring their College/School ID card with necessary items of their Needs.
----
12. If Attendees have any Dietary restrictions please send a request to meenhacks@gmail.com.
----
13. If any attendes require Stay before or After the Event, they should send a request to meenhacks@gmail.com.
----
14. The Certificates will be in Digital Formats and will be emailed to you in 30 Days prior the Event.
----
15. Our community strives for Innovation. All solutions should be Original and Non Derivative.  
----
16. All the Hacks should be either be **openly** available in GitHub or GitLab and should be licensed under MIT/BSD 3-Clause/GPL 3.0/2.0/AGPL Licensing.
----
17. Decision of the jury is final.
----
18. Prize is for a Team of 5 if the Team doesn't have  5 Members, the Organizers have full authority to **Cut down the Prize Money**
---
