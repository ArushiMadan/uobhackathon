git clone https://github.com/meenhacks/meenhacks.github.io.git 
cd meenhacks.github.io 
python -m SimpleHTTPServer || python -m http.server || python3 -m http.server
